# Career memo — Data Job Market Intelligence

## Purpose
This project explores a sample of job postings to connect role demand, required skills, work arrangements, locations, and salary ranges.

## What the analysis is designed to answer
- Which roles have the highest listed salary ceilings?
- Which skills appear most frequently across postings?
- How do Remote, Hybrid, and On-site postings compare?
- Which locations have the most postings?
- Which skills are associated with higher salary ranges?

## Practical learning takeaways
Use the in-demand-skills query to identify skills that recur across postings, then compare those skills with the skills-salary overlap query. Treat salary comparisons as descriptive, not causal: a higher salary may also reflect seniority, role type, location, or other factors.

## Important limitation
The included dataset is a synthetic/sample practice dataset. Its patterns demonstrate SQL and Power BI methods; they do not establish current hiring demand or market-wide salary benchmarks. Validate career decisions with current, real job postings before acting on the findings.
