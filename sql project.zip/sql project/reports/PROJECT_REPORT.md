# Project Report
## Data Job Market Intelligence

### 1. Introduction
This project uses SQL and Power BI to explore job-posting data. It examines job roles, companies, locations, work arrangements, salaries, and required skills.

### 2. Business question
Which skills, locations, and role types pay best, and what does the analyst market actually ask for?

### 3. Objectives
- Import and inspect a job-postings dataset.
- Design a normalized job-posting warehouse.
- Separate companies, locations, postings, skills, posting-skill relationships, salaries, and snapshots.
- Analyze high-paying roles, in-demand skills, work types, locations, and skill-salary overlap.
- Present key findings in an interactive one-page Power BI dashboard.

### 4. Dataset
The project folder includes `data/raw/data_job_market_sample_1000.csv`. It contains job identifiers, job titles, company names, locations, work types, experience levels, minimum and maximum salary values, currency, posted dates, and semicolon-separated skills. The dataset is a synthetic/sample learning dataset with 1,000 postings, not a live market census.

### 5. Tools and technologies
- MySQL 8.x and MySQL Workbench
- Power BI Desktop
- Visual Studio Code
- CSV

### 6. Database design
The warehouse contains:
- `companies`: unique company names.
- `locations`: unique location names.
- `postings`: one row per job posting, linked to company and location.
- `skills`: unique skill names.
- `posting_skills`: bridge table for the many-to-many relationship between postings and skills.
- `salaries`: salary minimum, maximum, and currency for each posting.
- `snapshots`: dated summary metrics.

### 7. Data preparation
The CSV is imported into `data_job_market_sample_1000`. Company and location names are deduplicated. Semicolon-separated skills are split into individual skill records. The `posting_skills` bridge table connects each job posting to its skills. Dates are parsed into SQL DATE values.

### 8. SQL analysis
The SQL scripts provide:
1. Top 10 postings by maximum salary.
2. Most frequently requested skills.
3. Remote, Hybrid, and On-site posting counts and average salary midpoint.
4. Top locations by posting count.
5. Skills-salary overlap using average salary midpoint for postings requiring each skill.
6. KPI validation queries and reusable views.

### 9. Power BI dashboard
The documented one-page dashboard includes KPI cards for total job postings, companies, locations, skills, and average maximum salary. Its charts cover top-paying roles, in-demand skills, postings by location, salary by work type, and salary by skill. A `work_type` slicer filters Remote, Hybrid, and On-site postings.

### 10. Results and interpretation
Conversation-based dashboard checks recorded 1,000 distinct job postings, 10 distinct locations, and 16 distinct skills. These values should be rechecked against the refreshed SQL/Power BI model before final publication. Company count and salary statistics should be copied from the actual final query outputs, not estimated.

Salary values in the CSV are INR. The average of `salary_max` is the average upper bound of salary ranges; it is not the average salary midpoint. For a range-based estimate, use `(salary_min + salary_max) / 2`. Do not label raw INR values as LPA without dividing by 100,000. Power BI display units can abbreviate values, so check the formatting before interpreting a card.

### 11. Limitations
- The included dataset is synthetic/sample data.
- Results describe this dataset only and cannot be generalized to the entire job market.
- Salary differences may be influenced by experience, job title, location, and other factors.
- Skill-salary overlap is descriptive and does not prove a skill causes a higher salary.

### 12. Conclusion
The project demonstrates a complete introductory workflow: importing a dataset, designing a normalized relational schema, transforming skills into a many-to-many model, writing analytical SQL queries and views, and presenting results through an interactive Power BI report.

### 13. Future enhancements
- Replace the sample dataset with a verified public job-postings dataset.
- Add refreshable snapshots and time-based trends.
- Add filters for experience level, location, and job title.
- Compare salary distributions by experience and role.
- Publish the PBIX and PDF report with source and methodology notes.
