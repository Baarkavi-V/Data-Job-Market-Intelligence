# Power BI dashboard guide

## Dashboard title
**DATA JOB MARKET INTELLIGENCE**

Subtitle: **Skills, Salary & Employment Trends**

## Theme recorded in the project conversation
- Dark chocolate-brown page background.
- Blue title text; beige/cream accents and borders.
- Keep all visuals on one report page.
- The logo concept is a briefcase + magnifying glass + rising bar chart. Add the transparent logo image as an image visual if you have saved it locally.

## KPI cards (top row)
1. **Total Job Postings** — `job_id` → Count (Distinct). Conversation verification: 1,000.
2. **Total Companies** — `company_name` → Count (Distinct). Verify after refresh.
3. **Total Locations** — `location` → Count (Distinct). Conversation verification: 10.
4. **Total Skills** — normalized `skills` column → Count (Distinct). Conversation verification: 16.
5. **Average Maximum Salary** — `salary_max` → Average. Do not use Distinct Count. Check currency and display units before adding a currency/LPA label.

## Main visuals (one page)
1. **Top 10 Highest Paying Job Roles** — Clustered bar chart; Axis: `job_title`; Values: `salary_max` (Average is usually more meaningful than Sum for comparing roles); Top N = 10; sort descending.
2. **In-Demand Skills** — Column/bar chart; Axis: normalized `skills`; Values: Count of distinct `job_id`.
3. **Job Postings by Location** — Donut chart; Legend: `location`; Values: Count of distinct `job_id`.
4. **Average Salary by Work Type** — Column or line chart; Axis: `work_type`; Values: Average of salary midpoint if available. If using `salary_max`, title it “Average Maximum Salary by Work Type”.
5. **Average Salary by Skill** — Funnel chart used in the conversation; Category: normalized `skills`; Values: Average of `salary_max`. Consider a bar chart if the funnel makes comparisons hard to read.

## Slicer
- Add a Slicer visual.
- Drag `work_type` into the slicer field.
- It should show Remote, Hybrid, and On-site.
- To change the slicer style, select it → Format visual → Slicer settings → Options/Style → Dropdown (label names differ by Power BI version).
- Increase item text size from the Format visual pane, under Values / Items / Slicer settings depending on version.
- Test that selecting one work type filters all relevant visuals.

## Power BI data preparation
The conversation records that the original `skills` field was split by semicolon into columns, then `skills.1` to `skills.7` were unpivoted; `Attribute` was removed and `Value` renamed to `skills`. This produces a normalized skill list for charts. Keep a copy of the original postings table for job-level counts to avoid counting each job multiple times after unpivoting.

## Salary warning
The CSV salary currency is INR. The salary fields are raw numeric INR amounts. A card showing `832.30` may be Power BI's display-unit abbreviation for approximately ₹832.30K, not ₹832.30. Check Format visual → Callout value → Display units = None (or label as ₹ thousands). Do not call it LPA unless you convert the value into lakhs (divide INR by 100,000).

## Save the report
In Power BI Desktop: File → Save As → `power_bi/Data_Job_Market_Intelligence.pbix`.
The PBIX file was not available to include in this ZIP, so this guide is a reproducible build record, not the actual PBIX.
