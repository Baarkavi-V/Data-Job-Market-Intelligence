-- 04. Reusable analysis views
USE job_market_analysis;

CREATE OR REPLACE VIEW top_paying_jobs AS
SELECT p.job_title, c.company_name, l.location_name,
       s.salary_min, s.salary_max, s.currency
FROM postings p
JOIN companies c ON c.company_id = p.company_id
JOIN locations l ON l.location_id = p.location_id
JOIN salaries s ON s.job_id = p.job_id;

CREATE OR REPLACE VIEW in_demand_skills AS
SELECT sk.skill_name, COUNT(DISTINCT ps.job_id) AS job_count
FROM posting_skills ps
JOIN skills sk ON sk.skill_id = ps.skill_id
GROUP BY sk.skill_id, sk.skill_name;

CREATE OR REPLACE VIEW work_type_analysis AS
SELECT p.work_type, COUNT(*) AS total_jobs,
       ROUND(AVG((s.salary_min + s.salary_max) / 2), 2) AS average_midpoint_salary,
       s.currency
FROM postings p
JOIN salaries s ON s.job_id = p.job_id
GROUP BY p.work_type, s.currency;

CREATE OR REPLACE VIEW top_job_locations AS
SELECT l.location_name, COUNT(*) AS total_jobs
FROM postings p
JOIN locations l ON l.location_id = p.location_id
GROUP BY l.location_id, l.location_name;

-- Skills-salary overlap view
CREATE OR REPLACE VIEW skills_salary_overlap AS
SELECT sk.skill_name,
       COUNT(DISTINCT ps.job_id) AS job_count,
       ROUND(AVG((sa.salary_min + sa.salary_max) / 2), 2) AS average_midpoint_salary,
       sa.currency
FROM posting_skills ps
JOIN skills sk ON sk.skill_id = ps.skill_id
JOIN salaries sa ON sa.job_id = ps.job_id
GROUP BY sk.skill_id, sk.skill_name, sa.currency;

SHOW FULL TABLES WHERE Table_type = 'VIEW';
