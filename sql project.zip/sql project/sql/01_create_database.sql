-- 01. Create the project database (MySQL 8.x)
CREATE DATABASE IF NOT EXISTS job_market_analysis
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE job_market_analysis;

-- Import data_job_market_sample_1000.csv into a table named
-- data_job_market_sample_1000 before running 02_create_warehouse_and_load.sql.
