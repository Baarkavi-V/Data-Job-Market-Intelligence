-- 03. Market analysis queries
USE job_market_analysis;

-- A. Top 10 highest maximum salary postings
SELECT p.job_title, c.company_name, l.location_name,
       s.salary_min, s.salary_max, s.currency
FROM postings p
JOIN companies c ON c.company_id = p.company_id
JOIN locations l ON l.location_id = p.location_id
JOIN salaries s ON s.job_id = p.job_id
ORDER BY s.salary_max DESC
LIMIT 10;

-- B. Most frequently requested skills
SELECT sk.skill_name, COUNT(DISTINCT ps.job_id) AS job_count
FROM posting_skills ps
JOIN skills sk ON sk.skill_id = ps.skill_id
GROUP BY sk.skill_id, sk.skill_name
ORDER BY job_count DESC
LIMIT 10;

-- C. Remote / Hybrid / On-site posting and salary comparison.
-- Salary uses the midpoint of the posted range.
SELECT p.work_type,
       COUNT(*) AS total_jobs,
       ROUND(AVG((s.salary_min + s.salary_max) / 2), 2) AS average_midpoint_salary,
       s.currency
FROM postings p
JOIN salaries s ON s.job_id = p.job_id
GROUP BY p.work_type, s.currency
ORDER BY total_jobs DESC;

-- D. Top locations by posting count
SELECT l.location_name, COUNT(*) AS total_jobs
FROM postings p
JOIN locations l ON l.location_id = p.location_id
GROUP BY l.location_id, l.location_name
ORDER BY total_jobs DESC
LIMIT 10;

-- E. Skills-salary overlap: average salary midpoint for jobs requiring each skill.
SELECT sk.skill_name,
       COUNT(DISTINCT ps.job_id) AS job_count,
       ROUND(AVG((sa.salary_min + sa.salary_max) / 2), 2) AS average_midpoint_salary,
       sa.currency
FROM posting_skills ps
JOIN skills sk ON sk.skill_id = ps.skill_id
JOIN salaries sa ON sa.job_id = ps.job_id
GROUP BY sk.skill_id, sk.skill_name, sa.currency
ORDER BY average_midpoint_salary DESC;

-- F. KPI checks
SELECT COUNT(DISTINCT job_id) AS total_job_postings FROM postings;
SELECT COUNT(DISTINCT company_id) AS total_companies FROM postings;
SELECT COUNT(DISTINCT location_id) AS total_locations FROM postings;
SELECT COUNT(*) AS total_unique_skills FROM skills;
SELECT currency,
       ROUND(AVG(salary_max), 2) AS average_maximum_salary,
       ROUND(AVG((salary_min + salary_max) / 2), 2) AS average_midpoint_salary
FROM salaries
GROUP BY currency;
