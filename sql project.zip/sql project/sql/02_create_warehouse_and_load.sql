-- 02. Build a normalized warehouse from the imported raw CSV table.
-- MySQL 8.x. Run after importing the CSV as data_job_market_sample_1000.
USE job_market_analysis;

-- Inspect the raw import before transforming it.
SELECT COUNT(*) AS raw_rows FROM data_job_market_sample_1000;
SELECT * FROM data_job_market_sample_1000 LIMIT 10;

-- Re-create project tables so this script can be rerun during practice.
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS posting_skills;
DROP TABLE IF EXISTS salaries;
DROP TABLE IF EXISTS postings;
DROP TABLE IF EXISTS skills;
DROP TABLE IF EXISTS locations;
DROP TABLE IF EXISTS companies;
DROP TABLE IF EXISTS snapshots;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE companies (
    company_id INT AUTO_INCREMENT PRIMARY KEY,
    company_name VARCHAR(150) NOT NULL UNIQUE
);

INSERT INTO companies (company_name)
SELECT DISTINCT TRIM(company_name)
FROM data_job_market_sample_1000
WHERE company_name IS NOT NULL AND TRIM(company_name) <> '';

CREATE TABLE locations (
    location_id INT AUTO_INCREMENT PRIMARY KEY,
    location_name VARCHAR(100) NOT NULL UNIQUE
);

INSERT INTO locations (location_name)
SELECT DISTINCT TRIM(location)
FROM data_job_market_sample_1000
WHERE location IS NOT NULL AND TRIM(location) <> '';

CREATE TABLE postings (
    job_id INT PRIMARY KEY,
    job_title VARCHAR(150),
    company_id INT,
    location_id INT,
    work_type VARCHAR(50),
    experience_level VARCHAR(50),
    posted_date DATE,
    CONSTRAINT fk_postings_company FOREIGN KEY (company_id) REFERENCES companies(company_id),
    CONSTRAINT fk_postings_location FOREIGN KEY (location_id) REFERENCES locations(location_id)
);

-- The supplied CSV uses ISO dates (YYYY-MM-DD). STR_TO_DATE handles this format.
INSERT INTO postings
    (job_id, job_title, company_id, location_id, work_type, experience_level, posted_date)
SELECT
    d.job_id,
    d.job_title,
    c.company_id,
    l.location_id,
    d.work_type,
    d.experience_level,
    COALESCE(
        STR_TO_DATE(d.posted_date, '%Y-%m-%d'),
        STR_TO_DATE(d.posted_date, '%d/%m/%Y')
    )
FROM data_job_market_sample_1000 AS d
LEFT JOIN companies AS c ON TRIM(d.company_name) = c.company_name
LEFT JOIN locations AS l ON TRIM(d.location) = l.location_name;

CREATE TABLE skills (
    skill_id INT AUTO_INCREMENT PRIMARY KEY,
    skill_name VARCHAR(100) NOT NULL UNIQUE
);

-- Split semicolon-separated skills into individual normalized rows.
INSERT IGNORE INTO skills (skill_name)
SELECT DISTINCT TRIM(
    SUBSTRING_INDEX(SUBSTRING_INDEX(d.skills, ';', n.n), ';', -1)
)
FROM data_job_market_sample_1000 AS d
JOIN (
    SELECT 1 n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL
    SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL
    SELECT 9 UNION ALL SELECT 10
) AS n
  ON n.n <= 1 + LENGTH(d.skills) - LENGTH(REPLACE(d.skills, ';', ''))
WHERE d.skills IS NOT NULL
  AND TRIM(d.skills) <> ''
  AND TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(d.skills, ';', n.n), ';', -1)) <> '';

CREATE TABLE posting_skills (
    job_id INT NOT NULL,
    skill_id INT NOT NULL,
    PRIMARY KEY (job_id, skill_id),
    CONSTRAINT fk_posting_skills_posting FOREIGN KEY (job_id) REFERENCES postings(job_id),
    CONSTRAINT fk_posting_skills_skill FOREIGN KEY (skill_id) REFERENCES skills(skill_id)
);

INSERT IGNORE INTO posting_skills (job_id, skill_id)
SELECT d.job_id, s.skill_id
FROM data_job_market_sample_1000 AS d
JOIN (
    SELECT 1 n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL
    SELECT 5 UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL
    SELECT 9 UNION ALL SELECT 10
) AS n
  ON n.n <= 1 + LENGTH(d.skills) - LENGTH(REPLACE(d.skills, ';', ''))
JOIN skills AS s
  ON s.skill_name = TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(d.skills, ';', n.n), ';', -1))
JOIN postings AS p ON p.job_id = d.job_id
WHERE d.skills IS NOT NULL AND TRIM(d.skills) <> '';

CREATE TABLE salaries (
    salary_id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT NOT NULL UNIQUE,
    salary_min DECIMAL(14,2),
    salary_max DECIMAL(14,2),
    currency VARCHAR(10),
    CONSTRAINT fk_salaries_posting FOREIGN KEY (job_id) REFERENCES postings(job_id)
);

INSERT INTO salaries (job_id, salary_min, salary_max, currency)
SELECT d.job_id, d.salary_min, d.salary_max, d.currency
FROM data_job_market_sample_1000 AS d
JOIN postings AS p ON p.job_id = d.job_id;

CREATE TABLE snapshots (
    snapshot_id INT AUTO_INCREMENT PRIMARY KEY,
    snapshot_date DATE NOT NULL,
    total_jobs INT,
    average_salary DECIMAL(14,2)
);

-- One snapshot row per execution. Average salary is the midpoint of min/max.
INSERT INTO snapshots (snapshot_date, total_jobs, average_salary)
SELECT CURDATE(), COUNT(*),
       ROUND(AVG((salary_min + salary_max) / 2), 2)
FROM salaries;

-- Validation counts
SELECT COUNT(*) AS companies_count FROM companies;
SELECT COUNT(*) AS locations_count FROM locations;
SELECT COUNT(*) AS postings_count FROM postings;
SELECT COUNT(*) AS skills_count FROM skills;
SELECT COUNT(*) AS posting_skill_links FROM posting_skills;
SELECT COUNT(*) AS salary_rows FROM salaries;
SELECT * FROM snapshots ORDER BY snapshot_id DESC LIMIT 5;
