# Assets

Place the transparent project logo, final Power BI dashboard screenshot, and any approved report images in this folder. The original PBIX and logo image were not available as files to package in this ZIP.
