# Manual setup: VS Code + MySQL + Power BI

## A. Open the project in VS Code
1. Extract the ZIP file.
2. Open Visual Studio Code.
3. Select **File → Open Folder**.
4. Choose the extracted folder named `sql project`.
5. In Explorer, expand `sql`, `data`, `power_bi`, and `reports`.
6. Install a SQL syntax-highlighting extension if desired. VS Code is used to edit the project files; MySQL Workbench is used to execute the SQL.

## B. Import the CSV into MySQL Workbench
1. Open MySQL Workbench and connect to your local MySQL server.
2. Open `sql/01_create_database.sql` and execute it.
3. In the SCHEMAS panel, refresh and select `job_market_analysis`.
4. Right-click the schema → **Table Data Import Wizard**.
5. Select `data/raw/data_job_market_sample_1000.csv`.
6. Create a table named exactly `data_job_market_sample_1000`.
7. Confirm the columns are mapped correctly. The CSV contains `job_id`, `job_title`, `company_name`, `location`, `work_type`, `experience_level`, `salary_min`, `salary_max`, `currency`, `posted_date`, and `skills`. If an extra index column is present in the file, do not use it as the job ID.
8. Finish the import.
9. Run `SELECT COUNT(*) FROM data_job_market_sample_1000;` and confirm the imported row count.

## C. Build the normalized warehouse
1. Open `sql/02_create_warehouse_and_load.sql` in MySQL Workbench.
2. Execute the complete script.
3. Check the validation queries at the end.
4. Expected core tables: `companies`, `locations`, `postings`, `skills`, `posting_skills`, `salaries`, `snapshots`.
5. If you get a duplicate-key or already-exists error, check whether you executed only part of the script. The script drops and recreates its project tables before rebuilding them; it does not drop the raw imported CSV table.

## D. Run analysis queries and views
1. Execute `sql/03_market_analysis_queries.sql`.
2. Review each result set: top-paying jobs, in-demand skills, work type, locations, skills-salary overlap, and KPI checks.
3. Execute `sql/04_create_analysis_views.sql`.
4. In MySQL, run `SHOW FULL TABLES WHERE Table_type = 'VIEW';`.
5. Export result grids to CSV if you want separate portfolio evidence.

## E. Build / connect Power BI
1. Open Power BI Desktop.
2. Choose **Get Data** and connect either to MySQL (`job_market_analysis`) or import the raw CSV.
3. If connecting to MySQL, select the relevant normalized tables/views. If importing the raw CSV, use Power Query to split `skills` by delimiter `;` into columns, select the skill columns, choose **Unpivot Columns**, remove `Attribute`, and rename `Value` to `skills`.
4. Keep a job-level table for total job counts; the unpivoted skill table has multiple rows per job and must not be used to count total jobs without distinct count.
5. Create the five KPI cards and five visuals described in `power_bi/POWER_BI_GUIDE.md`.
6. Add the `work_type` slicer and test Remote, Hybrid, and On-site selections.
7. Format the page with the project's brown/blue/beige theme.
8. Save as `power_bi/Data_Job_Market_Intelligence.pbix`.

## F. Finish the portfolio
1. Update `reports/CAREER_MEMO.md` with your actual query findings.
2. Capture a clear screenshot of the finished Power BI page and save it under `power_bi/`.
3. Export the SQL query results and the dashboard to PDF if required by your assignment.
4. Review the report for correct currency labels and synthetic-data limitations.
5. Add a GitHub repository with this folder structure and push the project.

## G. GitHub commands
Run these in the VS Code terminal from inside `sql project`:

```bash
git init
git add .
git commit -m "Add Data Job Market Intelligence SQL and Power BI project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/sql-project.git
git push -u origin main
```

Replace the URL with your own GitHub repository URL. Do not share passwords or access tokens.
