# Data Job Market Intelligence

A portfolio project using **MySQL + Power BI** to explore job postings, salary ranges, required skills, work arrangements, and locations.

> **Data note:** The included CSV is a 1,000-row synthetic/sample dataset used for learning and demonstration. It should not be presented as a live or representative survey of the entire job market.

## Project question
Which skills, locations, and role types pay best, and what does the analyst market actually ask for?

## Tools
- MySQL 8.x / MySQL Workbench
- Power BI Desktop
- Visual Studio Code (editing SQL, Markdown and project files)
- CSV dataset

## Folder structure

```text
sql project/
├── README.md
├── .gitignore
├── data/
│   ├── raw/
│   │   └── data_job_market_sample_1000.csv
│   └── processed/
├── sql/
│   ├── 01_create_database.sql
│   ├── 02_create_warehouse_and_load.sql
│   ├── 03_market_analysis_queries.sql
│   └── 04_create_analysis_views.sql
├── power_bi/
│   └── POWER_BI_GUIDE.md
├── reports/
│   ├── PROJECT_REPORT.md
│   ├── PROJECT_REPORT.pdf
│   └── CAREER_MEMO.md
├── docs/
│   └── MANUAL_STEPS_VS_CODE.md
└── assets/
    └── README.md
```

## Quick start
1. Open this folder in VS Code.
2. Read `docs/MANUAL_STEPS_VS_CODE.md`.
3. In MySQL Workbench, create the database using `sql/01_create_database.sql`.
4. Import the CSV into a raw table named `data_job_market_sample_1000` (instructions are in the manual guide).
5. Run `sql/02_create_warehouse_and_load.sql`.
6. Run `sql/03_market_analysis_queries.sql` and `sql/04_create_analysis_views.sql`.
7. Connect Power BI to MySQL or import the raw CSV and reproduce the visuals described in `power_bi/POWER_BI_GUIDE.md`.
8. Save your actual Power BI report as `power_bi/Data_Job_Market_Intelligence.pbix`.

## Dashboard visuals documented from the conversation
- Top 10 Highest Paying Job Roles
- In-Demand Skills
- Job Postings by Location
- Average Salary by Work Type
- Average Salary by Skill
- Work Type slicer: Remote / Hybrid / On-site
- KPI cards: Total Job Postings, Total Companies, Total Locations, Total Skills, Average Maximum Salary

The PBIX itself was not present among the files available for packaging. The guide records the dashboard layout and build steps; place your own `.pbix` file in `power_bi/` after saving it from Power BI Desktop.

## Important data interpretation
- The source CSV identifies salary currency as INR.
- Use `salary_min` and `salary_max` in the same currency; do not label a raw INR value as LPA without converting it.
- For a representative salary estimate, use the midpoint `(salary_min + salary_max) / 2`. The dashboard's `Average Maximum Salary` card is a different metric: average of `salary_max`.
- Power BI may abbreviate large values. Set Display units to **None** or clearly label the unit (for example, ₹ thousands) so `832.30` is not mistaken for ₹832.30.
- The conversation recorded these dashboard checks: 1,000 distinct job IDs, 10 distinct locations, and 16 distinct skills. Company count and salary KPI should be verified from the refreshed model before publishing.

## GitHub publishing checklist
- Add your real `.pbix` and final dashboard screenshot.
- Confirm the SQL scripts run successfully on your MySQL version.
- Add the final PDF portfolio report and exported query results if required.
- Do not commit passwords, connection strings, personal data, or large unnecessary temporary files.
